import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import {UsersService} from '../../services/users.service';
import { FormsModule }   from '@angular/forms';

@Component({
  selector: 'app-addproject',
  templateUrl: './addproject.component.html',
  styleUrls: ['./addproject.component.scss']
})
export class AddprojectComponent {

  constructor(private _UserService: UsersService, private router: Router) { }


  onSubmit(formValue){

    console.log("NAME:" + "" + formValue.ProjectName);

    const project = {
      ProjectCode: formValue.ProjectCode,
    ProjectName: formValue.ProjectName,
    ProjectStartDate: formValue.ProjectStartDate,
    ProjectEndDate: formValue.ProjectEndDate,
    IsActive: formValue.IsActive,
    ProjectType: formValue.ProjectType,
    }

    this._UserService.addProject(project).subscribe(data => {
     console.log("Calling Service")
    });
  }
}
