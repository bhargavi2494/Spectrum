import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resource-managment',
  templateUrl: './resource-managment.component.html',
  styleUrls: ['./resource-managment.component.scss']
})
export class ResourceManagmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
