import { Component, OnInit } from '@angular/core';
import {UsersService} from '../../services/users.service';

@Component({
  selector: 'app-project-details',
  templateUrl: './project-details.component.html',
  styleUrls: ['./project-details.component.scss']
})
export class ProjectDetailsComponent implements OnInit {

  constructor(private _UserService : UsersService) { }
  project: any = [];
  ngOnInit() {

    this.project = [];
    this._UserService.getProject().subscribe((data: {}) => {
      console.log('project' + " " + data);
      this.project = data;
    });

  }

}
