import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addresource',
  templateUrl: './addresource.component.html',
  styleUrls: ['./addresource.component.scss']
})
export class AddresourceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
