import { Injectable } from '@angular/core';
import { HttpModule, Http, Headers } from '@angular/http';
import { HttpClient, HttpHeaders, HttpErrorResponse, HttpParams } from '@angular/common/http';
//import 'rxjs/add/operator/map';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token'
  })
};
@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor(private _http: HttpClient) {
    console.log('Initializing Employee service...');
   }

   

   private extractData(res: Response){
     let body = res;
     return body || { };
   }

  getEmployee(): any{
    
    return this._http.get('http://localhost:3000/admin/getEmployee').pipe(
      map(this.extractData)
    );
    
  }


  getProject(): any{
    
    return this._http.get('http://localhost:3000/admin/getProject').pipe(
      map(this.extractData)
    );
  }

  getSingleEmployee(EmpID: any): Observable<{}>{
    console.log("EmpID" + " " + EmpID);

    let params = new HttpParams()
    .set('EmpID', EmpID)

    return this._http.get('http://localhost:3000/admin/getSingleEmployee/' + EmpID)
  }

  AddEmployee(user){
    let headers = new Headers();
    console.log("inside the AngularService:" + " " +JSON.stringify(user) );
    headers.append('Content-Type', 'application/json');
    return this._http.post('http://localhost:3000/admin/addEmployee/', user, httpOptions)
  }
  editEmployee(user){
    let headers = new Headers();
    console.log("inside the AngularService:" + " " +JSON.stringify(user) );
    headers.append('Content-Type', 'application/json');
    return this._http.put('http://localhost:3000/admin/editEmployee', user, httpOptions)
  }

  addProject(user){
    let headers = new Headers();
    console.log("inside the AngularService:" + " " +JSON.stringify(user) );
    headers.append('Content-Type', 'application/json');
    return this._http.post('http://localhost:3000/admin/addProject', user, httpOptions)
  }

  AddEffort(user){
    let headers = new Headers();
    console.log("inside the AngularService:" + " " +JSON.stringify(user) );
    headers.append('Content-Type', 'application/json');
    return this._http.post('http://localhost:3000/admin/AddEffort', user, httpOptions)
  }

}
