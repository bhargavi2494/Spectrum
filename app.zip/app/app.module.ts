import { BrowserModule } from '@angular/platform-browser';
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { ResourceManagmentComponent } from './components/resource-managment/resource-managment.component';
import { ProjectDetailsComponent } from './components/project-details/project-details.component';
import { TimeSheetComponent } from './components/time-sheet/time-sheet.component';
import { EmloyeeDetailComponent } from './components/emloyee-detail/emloyee-detail.component';

import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { AddEmployeeComponent } from './components/add-employee/add-employee.component';
import { EditemployeeComponent } from './components/editemployee/editemployee.component';
import { DeleteemployeeComponent } from './components/deleteemployee/deleteemployee.component';
import { AddprojectComponent } from './components/addproject/addproject.component';
import { EditprojectComponent } from './components/editproject/editproject.component';
import { VieweffortsComponent } from './components/viewefforts/viewefforts.component';
import { AddeffortsComponent } from './components/addefforts/addefforts.component';
import { EditeffortsComponent } from './components/editefforts/editefforts.component';
import { AddresourceComponent } from './components/addresource/addresource.component';
import { EditresourceComponent } from './components/editresource/editresource.component';
import { ViewresourceComponent } from './components/viewresource/viewresource.component';

import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    NavbarComponent,
    ResourceManagmentComponent,
    ProjectDetailsComponent,
    TimeSheetComponent,
    EmloyeeDetailComponent,
    AddEmployeeComponent,
    EditemployeeComponent,
    DeleteemployeeComponent,
    AddprojectComponent,
    EditprojectComponent,
    VieweffortsComponent,
    AddeffortsComponent,
    EditeffortsComponent,
    AddresourceComponent,
    EditresourceComponent,
    ViewresourceComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, 
    HttpModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
