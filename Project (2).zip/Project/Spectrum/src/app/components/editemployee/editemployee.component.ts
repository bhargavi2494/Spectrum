import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import {UsersService} from '../../services/users.service';
import { FormsModule }   from '@angular/forms';

@Component({
  selector: 'app-editemployee',
  templateUrl: './editemployee.component.html',
  styleUrls: ['./editemployee.component.scss']
})
export class EditemployeeComponent implements OnInit{

  constructor(private _UserService: UsersService, private router: Router, private route: ActivatedRoute) { }

  employee: any;
  EmpID : any;
  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.EmpID = params['EmpID'];
      console.log('email:' + this.EmpID);
    });
    console.log(this.EmpID);
    
    this._UserService.getSingleEmployee(this.EmpID)
      .subscribe(employee => {
          this.employee = employee;
        }
      );
  }
  onSubmit(formValue){

    console.log("NAME:" + "" + formValue.EmpName);

    const employee = {
      EmpName: formValue.EmpName,
    EmpID: formValue.EmpID,
    EmpEmail: formValue.EmpEmail,
    startDate: formValue.startDate ,
    endDate: formValue.endDate,
    primarySkill: formValue.primarySkill,
    secondarySkill: formValue.secondarySkill,
    empBand: formValue.empBand,
    Role: formValue.Role
    }

    this._UserService.editEmployee(employee).subscribe(data => {
     console.log("Calling Service")
    });

    this.router.navigate(['EDM']);
  }
}
