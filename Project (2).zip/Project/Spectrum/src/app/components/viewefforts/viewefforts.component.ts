import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewefforts',
  templateUrl: './viewefforts.component.html',
  styleUrls: ['./viewefforts.component.scss']
})
export class VieweffortsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
