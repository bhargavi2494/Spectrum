import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VieweffortsComponent } from './viewefforts.component';

describe('VieweffortsComponent', () => {
  let component: VieweffortsComponent;
  let fixture: ComponentFixture<VieweffortsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VieweffortsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VieweffortsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
