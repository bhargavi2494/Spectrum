import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import {UsersService} from '../../services/users.service';
import { FormsModule }   from '@angular/forms';


@Component({
  selector: 'app-addefforts',
  templateUrl: './addefforts.component.html',
  styleUrls: ['./addefforts.component.scss']
})
export class AddeffortsComponent {

  constructor(private _UserService: UsersService, private router: Router) { }


  onSubmit(formValue){

    console.log("NAME:" + "" + formValue.Effort);

    const effort = {
      ProjectID: formValue.ProjectID,
      Month: formValue.Month,
      Week: formValue.Week,
      Efforts: formValue.Efforts ,
    }

    this._UserService.AddEffort(effort).subscribe(data => {
     console.log("Calling Service")
    });
  }
}
