import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editproject',
  templateUrl: './editproject.component.html',
  styleUrls: ['./editproject.component.scss']
})
export class EditprojectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
