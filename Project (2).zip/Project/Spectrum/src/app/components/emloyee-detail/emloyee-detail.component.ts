import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import {UsersService} from '../../services/users.service';

@Component({
  selector: 'app-emloyee-detail',
  templateUrl: './emloyee-detail.component.html',
  styleUrls: ['./emloyee-detail.component.scss']
})
export class EmloyeeDetailComponent implements OnInit {

  constructor(private _UserService : UsersService) { }

  employee: any = [];
  ngOnInit() {
    this.employee = [];
    this._UserService.getEmployee().subscribe((data: {}) => {
      console.log('employee' + " " + data);
      this.employee = data;
    });
  }

}

// getProducts() {
//   this.products = [];
//   this.rest.getProducts().subscribe((data: {}) => {
//     console.log(data);
//     this.products = data;
//   });