import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResourceManagmentComponent } from './resource-managment.component';

describe('ResourceManagmentComponent', () => {
  let component: ResourceManagmentComponent;
  let fixture: ComponentFixture<ResourceManagmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResourceManagmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResourceManagmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
