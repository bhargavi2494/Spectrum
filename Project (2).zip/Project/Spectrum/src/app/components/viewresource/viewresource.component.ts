import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewresource',
  templateUrl: './viewresource.component.html',
  styleUrls: ['./viewresource.component.scss']
})
export class ViewresourceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
