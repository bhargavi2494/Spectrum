import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editefforts',
  templateUrl: './editefforts.component.html',
  styleUrls: ['./editefforts.component.scss']
})
export class EditeffortsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
