import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditeffortsComponent } from './editefforts.component';

describe('EditeffortsComponent', () => {
  let component: EditeffortsComponent;
  let fixture: ComponentFixture<EditeffortsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditeffortsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditeffortsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
