import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import {UsersService} from '../../services/users.service';
import { FormsModule }   from '@angular/forms';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.scss']
})
export class AddEmployeeComponent {

  constructor(private _UserService: UsersService, private router: Router) { }


  onSubmit(formValue){

    const employee = {
      EmpName: formValue.EmpName,
    EmpID: formValue.EmpID,
    EmpEmail: formValue.EmpEmail,
    startDate: formValue.startDate ,
    endDate: formValue.endDate,
    primarySkill: formValue.primarySkill,
    secondarySkill: formValue.secondarySkill,
    empBand: formValue.empBand,
    Role: formValue.Role
    }

    this._UserService.AddEmployee(employee).subscribe(data => {
    
    });
    this.router.navigate(['EDM']);
  }
}
