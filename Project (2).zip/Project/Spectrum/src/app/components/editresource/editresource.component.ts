import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editresource',
  templateUrl: './editresource.component.html',
  styleUrls: ['./editresource.component.scss']
})
export class EditresourceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
