// module.exports = {
//   database: 'mongodb://Divya:Password1@ds137857.mlab.com:37857/spectrum',
//   secret: 'spectrum'
// }

// module.exports = {
//   database: 'mongodb://vfc_db_user:vfc_db_user@ds117730.mlab.com:17730/vfc',
//   secret: 'spectrum'
// }

module.exports = {
  database: 'mongodb://spec:divya123@ds125994.mlab.com:25994/spectrum02',
  secret: 'spectrum'
}


